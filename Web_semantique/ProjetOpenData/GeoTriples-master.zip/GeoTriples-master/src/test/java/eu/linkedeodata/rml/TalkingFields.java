package eu.linkedeodata.rml;

import eu.linkedeodata.core.RMLTest;

public class TalkingFields extends RMLTest {

	public TalkingFields() {
		super("32633", "resources/test/rml/talkingfields-rml.ttl", null, "resources/test/rml/talkingfields-rml.nt");
	}
}
