package eu.linkedeodata.geotriples;


public class GeneralJoinOptimizer {
	public static GeneralNodeRelation optimize(GeneralNodeRelation r) { return r; }
}
