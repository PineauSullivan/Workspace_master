package eu.linkedeodata.geotriples.gui;

import org.apache.pivot.wtk.BoxPane;
import org.apache.pivot.wtk.TableView;

public class TablePackage {
	TableView tableView;
	BoxPane detailPane;
	
	public TablePackage() {
		
	}
}
