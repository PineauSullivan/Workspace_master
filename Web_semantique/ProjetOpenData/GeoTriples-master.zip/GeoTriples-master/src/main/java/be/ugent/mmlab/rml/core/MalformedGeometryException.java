package be.ugent.mmlab.rml.core;

public class MalformedGeometryException extends Exception {


	public MalformedGeometryException(String message) {
		super(message);
	}

}
