package be.ugent.mmlab.rml.function;

import be.ugent.mmlab.rml.model.TermMap.TermMapType;
import be.ugent.mmlab.rml.vocabulary.Vocab.QLTerm;

public class GeometryFunction extends AbstractFunction {
	
}
