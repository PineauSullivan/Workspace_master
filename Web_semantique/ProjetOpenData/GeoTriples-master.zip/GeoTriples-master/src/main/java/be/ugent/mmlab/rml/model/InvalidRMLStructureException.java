package be.ugent.mmlab.rml.model;

/**
 *
 * @author mielvandersande
 */
class InvalidRMLStructureException extends Exception {

    public InvalidRMLStructureException(String message) {
        super(message);
    }
    
}
