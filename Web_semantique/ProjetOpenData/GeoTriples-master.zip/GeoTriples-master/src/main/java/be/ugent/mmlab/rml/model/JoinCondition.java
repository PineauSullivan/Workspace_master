/* 
 * Copyright 2011 Antidot opensource@antidot.net
 * https://github.com/antidot/db2triples
 * 
 * DB2Triples is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation; either version 2 of 
 * the License, or (at your option) any later version.
 * 
 * DB2Triples is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/***************************************************************************
 *
 * R2RML Model : Join Condition Interface
 *
 * A join condition is a resource that has 
 * exactly two properties: 
 * 	- rr:child, whose value is known as the
 * 	  join condition's child column
 * 	- rr:parent, whose value is known as the
 * 	  join condition's parent column 
 *
 ****************************************************************************/
package be.ugent.mmlab.rml.model;

import java.io.Serializable;
import java.util.List;

import org.openrdf.model.URI;

public interface JoinCondition extends Serializable {
	
	/**
	 * Child reference must be a reference in the language defined by the logical source 
	 * of the triples map that contains the referencing object map
	 */
	public String getChild();
	
	/**
	 * Parent reference must be a reference in the language defined by the parent triples map and exist there.  
	 */
	public String getParent();

	public List<TermMap> getArgumentMap();
	public void setArgumentMap(List<TermMap> arguments);
	public URI getFunction();
	public void setFunction(URI function);

	public boolean isStructural();
	public TriplesMap getParentTriplesMap();
	public TriplesMap getChildTriplesMap();
}
