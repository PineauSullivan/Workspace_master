package org.d2rq.db.types;

public class SQLGeometry extends DataType {

	public SQLGeometry(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
