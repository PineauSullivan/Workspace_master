package org.d2rq.tmp;

import org.d2rq.algebra.NodeRelation;

public class JoinOptimizer {
	public static NodeRelation optimize(NodeRelation r) { return r; }
}
